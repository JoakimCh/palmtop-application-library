#include "lxapi.h"

LHWINDOW t;

void main(void)
{
printf("%i\n",sizeof(t.Title));
printf("%i\n",sizeof(t.Data));
getch();
}