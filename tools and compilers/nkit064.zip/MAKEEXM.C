#include  <stdio.h>
#include  <stdlib.h>
#include  <string.h>

FILE  *fp;
char  strbuf[256],hexbuf[10],*strptr,*hexptr;
int   i,skip;

void main(int argc,char *argv[])
{
  if(argc!=4) {puts("Usage: makeexm mapfile exefile Line\n");exit(1);}
  if((skip=atoi(argv[3]))==0) {puts("No Line\n");exit(1);}
  if((fp=fopen(argv[1],"r"))==NULL)
    {puts("Mapfile not found\n");exit(2);}
  while(skip--)  fgets(strbuf,256,fp);
  fclose(fp); strptr=strbuf; strcpy(hexbuf,"0x");
  while(*strptr==' ') strptr++;
  hexptr=hexbuf+2;for(i=0;i<4;i++) *hexptr++=*strptr++;
  if(*strptr!='0') {puts("Paragraph?\n");exit(3);}
  *hexptr=0;skip=(int )strtol(hexbuf,&strptr,16);
  if((fp=fopen(argv[2],"r+b"))==NULL)
    {puts("Outputfile Can't open\n");exit(4);}
  fwrite("DL",2,1,fp);fseek(fp,(long )0x1a,SEEK_SET);
  fwrite(&skip,2,1,fp);fclose(fp);
}
